import { Component } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem, CdkDrag } from '@angular/cdk/drag-drop';
import { NgStyle } from '@angular/common';
import { $, element } from 'protractor';
import { Url } from 'url';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class DragdropComponent {


  apple = [
    'apple'
  ]

  fish = [
    'fish'
  ]

  bottle = [
    'bottle'
  ]

  cap = [
    'cap'
  ]

  diaper = [
    'diaper'
  ]

  faxe = [
    'faxe'
  ]

  milk = [
    'milk'
  ]

  kande = [
    'kinde'
  ]

  restspand = [
    ''
  ]

  madspand = [
    ''
  ];

  metalspand = [
    ''
  ];

  plastspand = [
    ''
  ];

  drop(event: CdkDragDrop<string[]>, item: number) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
      Swal.fire({
        icon: 'error',
        title: 'Wrong..!',
        text: 'This kind of trash goes to..',
        footer: '<a href>Go back to frontpage</a>'
      })

    } else if (event.item.data === this.apple) {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
      Swal.fire({
        icon: 'success',
        title: 'Good job!',
        text: 'apple',
        confirmButtonText: 'Next!',
        confirmButtonColor: '#5AB8B6',
        footer: '<a href>Go back to frontpage</a>'
      })
    } else if (event.item.data === this.fish) {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
      Swal.fire({
        icon: 'success',
        title: 'Good job!',
        text: 'fish',
        confirmButtonText: 'Next!',
        confirmButtonColor: '#5AB8B6',
        footer: '<a href>Go back to frontpage</a>'
      })
    } else if (event.item.data === this.bottle) {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
      Swal.fire({
        icon: 'success',
        title: 'Good job!',
        text: 'bottle',
        confirmButtonText: 'Next!',
        confirmButtonColor: '#5AB8B6',
        footer: '<a href>Go back to frontpage</a>'
      })
    }
    else if (event.item.data === this.cap) {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
      Swal.fire({
        icon: 'success',
        title: 'Good job!',
        text: 'cap',
        confirmButtonText: 'Next!',
        confirmButtonColor: '#5AB8B6',
        footer: '<a href>Go back to frontpage</a>'
      })
    } else if (event.item.data === this.diaper) {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
      Swal.fire({
        icon: 'success',
        title: 'Good job!',
        text: 'diaper',
        confirmButtonText: 'Next!',
        confirmButtonColor: '#5AB8B6',
        footer: '<a href>Go back to frontpage</a>'
      })
    } else if (event.item.data === this.faxe) {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
      Swal.fire({
        icon: 'success',
        title: 'Good job!',
        text: 'faxe',
        confirmButtonText: 'Next!',
        confirmButtonColor: '#5AB8B6',
        footer: '<a href>Go back to frontpage</a>'
      })
    } else if (event.item.data === this.milk) {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
      Swal.fire({
        icon: 'success',
        title: 'Good job!',
        text: 'milk',
        confirmButtonText: 'Next!',
        confirmButtonColor: '#5AB8B6',
        footer: '<a href>Go back to frontpage</a>'
      })
    } else if (event.item.data === this.kande) {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
      Swal.fire({
        icon: 'success',
        title: 'Good job!',
        text: 'kande',
        confirmButtonText: 'Next!',
        confirmButtonColor: '#5AB8B6',
        footer: '<a href>Go back to frontpage</a>'
      })
    } else {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
      Swal.fire({
        icon: 'success',
        title: 'Good job!',
        text: 'Camilla er sejere end drengene and thats a fact',
        confirmButtonText: 'Next!',
        confirmButtonColor: '#5AB8B6',
        footer: '<a href>Go back to frontpage</a>'
      })

    }
  }

  drop1(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
      alert("nul")
    } else {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
      alert("skrrrr")

    }
  }

}