import { Component, Input } from '@angular/core';


@Component({
    selector: 'product',
    template: `
    <img class="img-responsive" src="{{ data.imageUrl }}">
    `
})

export class SkraldComponent {
    @Input() data;
}
